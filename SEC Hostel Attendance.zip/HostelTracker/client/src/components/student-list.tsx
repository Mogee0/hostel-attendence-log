import { useQuery, useMutation } from "@tanstack/react-query";
import { Student, InsertAttendance } from "@shared/schema";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Loader2, CheckCircle, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { ScrollArea } from "@/components/ui/scroll-area";

interface StudentListProps {
  roomNumber: string;
}

export function StudentList({ roomNumber }: StudentListProps) {
  const { toast } = useToast();

  const { data: students, isLoading } = useQuery<Student[]>({
    queryKey: [`/api/students/${roomNumber}`],
  });

  const markAttendanceMutation = useMutation({
    mutationFn: async (data: InsertAttendance) => {
      const res = await apiRequest("POST", "/api/attendance", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/attendance`] });
      toast({
        title: "Attendance marked",
        description: "Student attendance has been updated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to mark attendance",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleMarkAttendance = (studentId: number, isPresent: boolean) => {
    markAttendanceMutation.mutate({
      studentId,
      date: new Date(),
      isPresent,
    });
  };

  if (isLoading) {
    return (
      <div className="flex justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!students?.length) {
    return (
      <div className="text-center p-8 text-muted-foreground">
        No students found in room {roomNumber}
      </div>
    );
  }

  return (
    <div className="rounded-md border">
      <ScrollArea className="h-[calc(100vh-300px)] md:h-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead className="hidden md:table-cell">Course</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {students.map((student) => (
              <TableRow key={student.id}>
                <TableCell className="font-medium">
                  {student.name}
                  <div className="md:hidden text-sm text-muted-foreground">
                    {student.course}
                  </div>
                </TableCell>
                <TableCell className="hidden md:table-cell">{student.course}</TableCell>
                <TableCell>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-green-600"
                      onClick={() => handleMarkAttendance(student.id, true)}
                      disabled={markAttendanceMutation.isPending}
                    >
                      <CheckCircle className="h-4 w-4 mr-1" />
                      Present
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-destructive"
                      onClick={() => handleMarkAttendance(student.id, false)}
                      disabled={markAttendanceMutation.isPending}
                    >
                      <XCircle className="h-4 w-4 mr-1" />
                      Absent
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </ScrollArea>
    </div>
  );
}