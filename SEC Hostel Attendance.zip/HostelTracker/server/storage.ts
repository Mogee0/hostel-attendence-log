import { InsertUser, User, Student, InsertStudent, Attendance, InsertAttendance } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getStudentsByRoom(roomNumber: string): Promise<Student[]>;
  getStudent(id: number): Promise<Student | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  
  getAttendance(studentId: number, date: Date): Promise<Attendance | undefined>;
  getMonthlyAttendance(studentId: number, month: number, year: number): Promise<Attendance[]>;
  markAttendance(attendance: InsertAttendance): Promise<Attendance>;
  
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private students: Map<number, Student>;
  private attendance: Map<number, Attendance>;
  public sessionStore: session.Store;
  private currentId: { user: number; student: number; attendance: number };

  constructor() {
    this.users = new Map();
    this.students = new Map();
    this.attendance = new Map();
    this.currentId = { user: 1, student: 1, attendance: 1 };
    this.sessionStore = new MemoryStore({ checkPeriod: 86400000 });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId.user++;
    const user: User = { ...insertUser, id, isWarden: true };
    this.users.set(id, user);
    return user;
  }

  async getStudentsByRoom(roomNumber: string): Promise<Student[]> {
    return Array.from(this.students.values()).filter(
      (student) => student.roomNumber === roomNumber,
    );
  }

  async getStudent(id: number): Promise<Student | undefined> {
    return this.students.get(id);
  }

  async createStudent(student: InsertStudent): Promise<Student> {
    const id = this.currentId.student++;
    const newStudent: Student = { ...student, id };
    this.students.set(id, newStudent);
    return newStudent;
  }

  async getAttendance(studentId: number, date: Date): Promise<Attendance | undefined> {
    return Array.from(this.attendance.values()).find(
      (a) => a.studentId === studentId && a.date.getTime() === date.getTime()
    );
  }

  async getMonthlyAttendance(studentId: number, month: number, year: number): Promise<Attendance[]> {
    return Array.from(this.attendance.values()).filter(
      (a) => 
        a.studentId === studentId && 
        a.date.getMonth() === month &&
        a.date.getFullYear() === year
    );
  }

  async markAttendance(attendance: InsertAttendance): Promise<Attendance> {
    const id = this.currentId.attendance++;
    const newAttendance: Attendance = { ...attendance, id };
    this.attendance.set(id, newAttendance);
    return newAttendance;
  }
}

export const storage = new MemStorage();
