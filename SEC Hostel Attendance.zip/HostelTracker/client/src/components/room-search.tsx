import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface RoomSearchProps {
  onRoomSelect: (room: string) => void;
}

export function RoomSearch({ onRoomSelect }: RoomSearchProps) {
  const [roomNumber, setRoomNumber] = useState("");
  const { toast } = useToast();

  const handleSearch = () => {
    if (!roomNumber.trim()) {
      toast({
        title: "Room number required",
        description: "Please enter a room number to search",
        variant: "destructive",
      });
      return;
    }

    onRoomSelect(roomNumber.trim());
  };

  return (
    <div className="flex flex-col sm:flex-row gap-4">
      <Input
        type="text"
        placeholder="Enter room number..."
        value={roomNumber}
        onChange={(e) => setRoomNumber(e.target.value)}
        className="w-full sm:max-w-sm"
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            handleSearch();
          }
        }}
      />
      <Button onClick={handleSearch} className="w-full sm:w-auto">
        <Search className="h-4 w-4 mr-2" />
        Search
      </Button>
    </div>
  );
}