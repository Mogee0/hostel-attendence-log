import { NavBar } from "@/components/nav-bar";
import { useQuery } from "@tanstack/react-query";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Student } from "@shared/schema";
import { useState } from "react";
import { format } from "date-fns";
import { Download } from "lucide-react";

export default function ReportsPage() {
  const [roomFilter, setRoomFilter] = useState("");
  const [month, setMonth] = useState(new Date().getMonth());
  const [year, setYear] = useState(new Date().getFullYear());

  const { data: students, isLoading: studentsLoading } = useQuery<Student[]>({
    queryKey: ["/api/students", roomFilter],
    enabled: !!roomFilter,
  });

  const downloadReport = () => {
    // Create CSV content
    const csvContent = "data:text/csv;charset=utf-8," + 
      "Name,Room Number,Course,Date,Status\n" +
      students?.map(student => 
        `${student.name},${student.roomNumber},${student.course},${format(new Date(), 'yyyy-MM-dd')}`
      ).join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `SEC_Hotel_Attendance_${format(new Date(), 'MMMM_yyyy')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-background">
      <NavBar />
      <main className="container mx-auto p-6 space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Monthly Attendance Reports</h1>
          <Button onClick={downloadReport} className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Download Report
          </Button>
        </div>

        <div className="space-y-4">
          <div className="flex gap-4">
            <Input
              type="text"
              placeholder="Enter room number to filter..."
              value={roomFilter}
              onChange={(e) => setRoomFilter(e.target.value)}
              className="max-w-sm"
            />
            <select
              value={month}
              onChange={(e) => setMonth(parseInt(e.target.value))}
              className="border rounded-md px-3 py-2"
            >
              {Array.from({ length: 12 }, (_, i) => (
                <option key={i} value={i}>
                  {format(new Date(2024, i, 1), 'MMMM')}
                </option>
              ))}
            </select>
            <select
              value={year}
              onChange={(e) => setYear(parseInt(e.target.value))}
              className="border rounded-md px-3 py-2"
            >
              {[2024, 2025].map(y => (
                <option key={y} value={y}>{y}</option>
              ))}
            </select>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Room</TableHead>
                  <TableHead>Course</TableHead>
                  <TableHead>Present Days</TableHead>
                  <TableHead>Absent Days</TableHead>
                  <TableHead>Attendance %</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {students?.map((student) => {
                  const { data: attendance } = useQuery({
                    queryKey: [
                      `/api/attendance/${student.id}/${month}/${year}`,
                    ],
                  });

                  const presentDays = attendance?.filter((a: any) => a[4] === '✅ Present').length || 0;
                  const totalDays = attendance?.length || 0;
                  const attendancePercentage = totalDays ? (presentDays / totalDays) * 100 : 0;

                  return (
                    <TableRow key={student.id}>
                      <TableCell>{student.name}</TableCell>
                      <TableCell>{student.roomNumber}</TableCell>
                      <TableCell>{student.course}</TableCell>
                      <TableCell>{presentDays}</TableCell>
                      <TableCell>{totalDays - presentDays}</TableCell>
                      <TableCell>
                        <span className={attendancePercentage < 75 ? "text-destructive" : "text-green-600"}>
                          {attendancePercentage.toFixed(1)}%
                        </span>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </div>
      </main>
    </div>
  );
}