import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertStudentSchema, insertAttendanceSchema } from "@shared/schema";
import { sheetsService } from "./services/sheets";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Students APIs
  app.get("/api/students/:roomNumber", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const students = await storage.getStudentsByRoom(req.params.roomNumber);
    res.json(students);
  });

  app.post("/api/students", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const parseResult = insertStudentSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json(parseResult.error);
    }

    const student = await storage.createStudent(parseResult.data);
    res.status(201).json(student);
  });

  // Attendance APIs
  app.post("/api/attendance", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const parseResult = insertAttendanceSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json(parseResult.error);
    }

    const attendance = await storage.markAttendance(parseResult.data);
    const student = await storage.getStudent(attendance.studentId);

    if (!student) {
      return res.status(404).json({ message: "Student not found" });
    }

    // Sync with Google Sheets
    await sheetsService.appendAttendance({
      studentName: student.name,
      roomNumber: student.roomNumber,
      course: student.course,
      date: attendance.date.toISOString().split('T')[0],
      isPresent: attendance.isPresent
    });

    res.status(201).json(attendance);
  });

  app.get("/api/attendance/:studentId/:month/:year", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const { studentId, month, year } = req.params;
    const monthNum = parseInt(month);
    const yearNum = parseInt(year);

    try {
      // Get attendance from Google Sheets
      const sheetData = await sheetsService.getMonthlyReport(monthNum, yearNum);
      res.json(sheetData);
    } catch (error) {
      console.error('Error fetching attendance:', error);
      res.status(500).json({ message: "Failed to fetch attendance data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}