import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Home, BarChart2, LogOut, Menu } from "lucide-react";
import { useState } from "react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";

export function NavBar() {
  const [location] = useLocation();
  const { logoutMutation } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  const NavLinks = () => (
    <div className="flex flex-col md:flex-row items-start md:items-center space-y-4 md:space-y-0 md:space-x-4 text-sm font-medium">
      <Link href="/">
        <Button
          variant={location === "/" ? "secondary" : "ghost"}
          className="flex items-center text-primary-foreground hover:text-primary hover:bg-white w-full md:w-auto"
        >
          <Home className="h-4 w-4 mr-2" />
          Home
        </Button>
      </Link>
      <Link href="/reports">
        <Button
          variant={location === "/reports" ? "secondary" : "ghost"}
          className="flex items-center text-primary-foreground hover:text-primary hover:bg-white w-full md:w-auto"
        >
          <BarChart2 className="h-4 w-4 mr-2" />
          Reports
        </Button>
      </Link>
    </div>
  );

  return (
    <nav className="border-b bg-primary text-primary-foreground">
      <div className="container flex h-14 items-center justify-between md:justify-start">
        <Link href="/" className="flex items-center space-x-2">
          <span className="font-bold">Hostel Attendance</span>
        </Link>

        {/* Mobile menu */}
        <div className="md:hidden">
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 bg-primary text-primary-foreground">
              <SheetHeader>
                <SheetTitle className="text-primary-foreground">Menu</SheetTitle>
              </SheetHeader>
              <div className="mt-4 flex flex-col space-y-4">
                <NavLinks />
                <Button
                  variant="ghost"
                  onClick={() => logoutMutation.mutate()}
                  disabled={logoutMutation.isPending}
                  className="text-primary-foreground hover:text-primary hover:bg-white w-full"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>

        {/* Desktop menu */}
        <div className="hidden md:flex md:flex-1 items-center justify-between">
          <NavLinks />
          <Button
            variant="ghost"
            onClick={() => logoutMutation.mutate()}
            disabled={logoutMutation.isPending}
            className="text-primary-foreground hover:text-primary hover:bg-white"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>
    </nav>
  );
}