import { useAuth } from "@/hooks/use-auth";
import { NavBar } from "@/components/nav-bar";
import { RoomSearch } from "@/components/room-search";
import { StudentList } from "@/components/student-list";
import { AddStudentForm } from "@/components/add-student-form";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

export default function HomePage() {
  const { user } = useAuth();
  const [selectedRoom, setSelectedRoom] = useState<string>("");

  return (
    <div className="min-h-screen bg-background">
      <NavBar />
      <main className="container mx-auto p-6 space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Welcome, {user?.username}</h1>
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add New Student
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Student</DialogTitle>
              </DialogHeader>
              <AddStudentForm />
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-6">
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold">Mark Attendance</h2>
            <RoomSearch onRoomSelect={setSelectedRoom} />
          </div>

          {selectedRoom && (
            <StudentList roomNumber={selectedRoom} />
          )}
        </div>
      </main>
    </div>
  );
}